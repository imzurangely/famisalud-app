# FamiSalud Web — estructura organizada

Frontend basado en React, Vite, JavaScript, Tailwind CSS v4, React Router, Fetch, Lucide React, SweetAlert2 y Sonner.

## Requisitos
- Node.js 24 LTS
- npm 11 o compatible con el `package-lock.json`
- Backend FamiSalud iniciado en `http://localhost:3000`

## Instalación
1. Copia `.env.example` a `.env` y confirma `VITE_API_BASE_URL=http://localhost:3000/api`.
2. Ejecuta `npm ci` para una instalación reproducible (o `npm install` si es la primera configuración).
3. Ejecuta `npm run build`.
4. Ejecuta `npm run dev` y abre la URL mostrada por Vite.

## Estructura principal
- `src/features/`: módulos de negocio; sus componentes, hooks, páginas y servicios viven dentro del módulo.
- `src/routes/`: configuración central de rutas.
- `src/shared/`: componentes, configuración, contextos, rutas, estilos y utilidades reutilizables.
- `src/App.jsx`: punto de composición de rutas.
- `src/main.jsx`: punto de entrada y providers globales.

## Invitaciones
La pantalla de respuesta consulta `GET /invitations/preview?token=...` antes de permitir aceptar/rechazar. Asegúrate de tener aplicada en el backend la revisión que añade esa ruta (`src/modules/family-invitations/familyInvitation.routes.js`, controller, schema y service). La API debe exigir autenticación y comprobar que el correo autenticado coincide con el destinatario.

## Calidad de código
Se incluye `eslint.config.js` como base con reglas nativas. En esta entrega no se añadieron paquetes de ESLint ni un script `lint`, para no introducir dependencias nuevas sin necesidad; se puede habilitar en una etapa de herramientas.

## Seguridad de entorno
`.env` es local y no se distribuye en este ZIP. Usa `.env.example` como plantilla. No expongas tokens, credenciales ni variables de producción en variables `VITE_*`.

## Alcance actual
- Autenticación y recuperación conectadas a la API.
- Gestión de familias, perfiles e invitaciones.
- Alertas con SweetAlert2 y notificaciones breves con Sonner.
- Dashboard y pantallas preliminares para historia clínica, medicamentos, citas, documentos, notificaciones y perfil. Estas últimas se implementarán por etapas.
