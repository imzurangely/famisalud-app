# Fase Frontend 2 — Checklist de autenticación

## Instalación
- [x] Reemplazar el frontend con este ZIP (no combinar manualmente con el ZIP previo).
- [x] Ejecutar `npm install`.
- [x] Ejecutar `npm run build`; debe finalizar sin errores.
- [x] Verificar `VITE_API_BASE_URL=http://localhost:3000/api`.
- [x] Confirmar que el backend tenga `FRONTEND_URL=http://localhost:5173` (o el origen real de Vite) y CORS con credenciales.

## Registro e inicio de sesión
- [x] Registrar cuenta nueva con nombre, apellido, correo, contraseña y confirmación.
- [x] Revisar validaciones de contraseña y confirmación.
- [x] Tras registro, debe llegar a `/configurar-familia` porque la cuenta aún no tiene familia.
- [x] Elegir “Crear una familia”, introducir nombre y continuar: la API debe devolver éxito y llevar al dashboard.
- [x] Repetir con “Crear un espacio personal”; la petición debe enviar `isPersonal: true`.
- [x] Cerrar sesión desde el menú del avatar; debe ir a `/login`.
- [x] Iniciar sesión con credenciales correctas; debe entrar al dashboard o a configurar familia si no tiene familia.
- [x] Probar contraseña incorrecta: debe aparecer un mensaje sin romper la vista.

## Cookie y renovación
- [x] Abrir DevTools > Application/Storage > Cookies y verificar que la cookie de refresh está marcada HttpOnly.
- [x] Recargar el navegador con sesión activa; debe restaurarse la sesión mediante `/auth/refresh` y `/auth/me`.
- [x] Cerrar sesión y recargar; debe permanecer en `/login`.
- [ ] Dejar vencer o invalidar el access token en una sesión de prueba y probar una petición protegida: una renovación válida debe permitir reintentar la petición.

## Recuperación
- [x] Solicitar código desde `/recuperar-contrasena`.
- [x] Si la API devuelve `debugCode` en desarrollo, aparece identificado como código de desarrollo. En otro caso, aparece el mensaje genérico y se utiliza el código que llega al correo.
- [x] Introducir correo, código y nueva contraseña en `/restablecer-contrasena`.
- [x] Código incorrecto, vencido o agotado debe mostrar el error de la API.
- [x] La contraseña se actualiza y las sesiones anteriores se revocan; iniciar sesión con la contraseña nueva.

## Rutas y UX
- [x] Las rutas principales requieren autenticación.
- [x] Visitar `/login` con sesión iniciada redirige al área privada.
- [x] Registro/login/recuperación se ven en móvil y escritorio.
- [x] El tema claro/oscuro funciona en todas las pantallas de autenticación.
- [x] No se guarda access token ni contraseña en localStorage.

# FamiSalud — Fase Frontend 3: checklist de validación

Prueba en la base de desarrollo con cuentas que ya utilizaste para validar la API. No uses tokens fijos en el código del frontend.

## A. Tema visual

- [x] En `/login`, pulsa el botón de tema: cambia el panel claro al oscuro y viceversa.
- [x] Comprueba el cambio en `/registro`, `/recuperar-contrasena` y `/restablecer-contrasena`.
- [x] La preferencia se conserva al navegar y recargar.
- [x] Después de iniciar sesión, el mismo tema sigue aplicado en el dashboard.
- [x] Sidebar, panel de perfil, menú móvil e inputs mantienen contraste legible en ambos temas.

## B. Familias

- [x] Inicia sesión con una cuenta que pertenezca a varias familias: aparecen todas en el selector.
- [x] Selecciona otra familia: actualiza su nombre, rol y los perfiles mostrados.
- [x] Recarga la página: se conserva la familia seleccionada mientras la cuenta siga perteneciendo a ella.
- [x] Crea una familia adicional: aparece en la lista y queda seleccionada.
- [x] Crea un espacio personal con `isPersonal: true` y confirma que el backend lo registra como personal.

## C. Perfiles

- [x] Como administrador, crea un perfil manual con parentesco distinto de `OTRO`.
- [x] Como administrador, crea un perfil con parentesco `OTRO` y su texto personalizado.
- [x] Un administrador puede editar los datos personales y el parentesco dentro de la familia.
- [x] Un miembro puede editar los datos personales de su propio perfil, pero la interfaz no le permite cambiar el parentesco.
- [x] Un miembro no puede crear ni retirar perfiles de otras personas; el backend sigue respondiendo con el error de permisos si se intenta forzar una petición.
- [x] Retirar un perfil de la familia muestra confirmación y no promete borrar la historia clínica global.

## D. Invitaciones

- [x] Como administrador, crea una invitación a un correo que no pertenezca a la familia.
- [x] En desarrollo, si la API devuelve `debugToken`, aparece una tarjeta para copiar el token y abrir el enlace de prueba.
- [x] Como destinatario registrado, abre el enlace y acepta. Debe crearse la membresía y volver a la pantalla de familia.
- [x] Abre el enlace desde una sesión cerrada: después del login se conserva `?token=...`.
- [x] Si el destinatario no tiene cuenta, crea la cuenta desde el enlace de invitación y comprueba que puede aceptar antes de crear otro espacio inicial.
- [x] Rechaza una invitación pendiente y comprueba el mensaje resultante.
- [x] Reenvía una invitación pendiente desde la lista de invitaciones enviadas. La API debe devolver un token de desarrollo nuevo cuando corresponda.
- [x] Las invitaciones aceptadas, rechazadas o expiradas aparecen con su estado.

## E. Administración y auditoría

- [x] Como administrador, la pestaña Administración muestra transferir rol y auditoría.
- [x] Transfiere la administración a una cuenta que ya sea miembro activo de esa familia.
- [x] Confirma que el rol en `GET /families` cambia para ambas cuentas.
- [x] El nuevo administrador puede cargar la auditoría.
- [x] El administrador anterior deja de ver la pestaña de administración después de actualizar el rol.
- [x] Si el usuario destino no es miembro activo, se muestra el mensaje del backend y no se anuncia éxito.

## F. Regresión y compilación

- [x] Registro, login, refresh, logout y recuperación siguen funcionando.
- [x] La API de backend permanece sin modificaciones.
- [x] `npm run build` termina sin errores.
- [x] No aparecen errores en la consola del navegador durante los flujos anteriores.

# Fase frontend 4 — Checklist

## Historia clínica inicial

- [x] `/historia-clinica` consulta los perfiles de la familia activa.
- [x] El perfil propio se selecciona por defecto cuando aparece vinculado a la cuenta.
- [x] Cambiar de perfil vuelve a cargar los registros; cambiar de familia en el menú también.
- [x] Crear, actualizar y eliminar alergias funciona y actualiza la lista.
- [x] Crear, actualizar y eliminar condiciones médicas funciona.
- [x] Crear, actualizar y eliminar vacunas funciona; una próxima dosis anterior a la fecha de aplicación se rechaza en frontend y backend.
- [x] Crear, actualizar y eliminar signos vitales funciona; no se permite guardar sin al menos una medición numérica.
- [x] Un miembro no administrador puede gestionar solo el registro de su propio perfil; no puede gestionar datos clínicos de otros perfiles.
- [x] Mensajes breves usan Sonner; eliminaciones usan confirmación SweetAlert2.
- [x] Las respuestas `401`, `403`, `404` y `422` se muestran sin romper la página.

# Fase Frontend 5 — Citas y documentos

## Citas

- [x] La ruta `/citas` carga sin errores y muestra la familia/espacio seleccionado.
- [x] El selector de perfil muestra los miembros activos de la familia actual.
- [x] Se listan las citas del perfil y el filtro de estado funciona.
- [x] Una cuenta con permiso crea una cita válida: `201` y aparece en el listado.
- [x] Crear una cita con `appointmentType = OTRO` exige `customType`.
- [x] Una fecha de finalización anterior o igual al inicio se rechaza en el formulario.
- [x] La API bloquea citas dentro del intervalo mínimo de dos horas; el frontend muestra el error devuelto sin romper la pantalla.
- [x] Editar título, notas, horario y estado actualiza la cita.
- [x] Eliminar una cita requiere confirmación SweetAlert2; al confirmar, la tarjeta desaparece.
- [x] Un usuario sin permiso ve las citas en modo lectura y no ve acciones de escritura.
- [x] El botón «Documentos» navega a `/documentos` con el perfil y la cita seleccionados en los filtros.

## Documentos

- [x] La ruta `/documentos` carga documentos del perfil seleccionado.
- [x] Buscar por título, filtrar por categoría y filtrar por cita actualiza el listado.
- [x] Subir un PDF válido menor o igual a 10 MB devuelve `201` y agrega el documento al listado.
- [x] Subir JPG, PNG o WEBP válidos también funciona.
- [x] Archivo con formato no permitido o mayor a 10 MB muestra un error comprensible.
- [x] Categoría `OTRO` exige una categoría personalizada.
- [x] Se puede asociar un documento a una cita del mismo perfil.
- [x] Abrir el archivo usa `file_url` en una pestaña nueva.
- [x] Editar título/categoría/fecha conserva el archivo cuando no se elige uno nuevo.
- [x] Reemplazar un archivo actualiza el documento.
- [x] Eliminar el documento requiere confirmación; al confirmar, desaparece del listado.
- [x] Una cuenta sin permisos puede consultar los documentos, pero no ve acciones de alta, edición o eliminación.
